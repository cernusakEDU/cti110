const images = [
    'gray-wp1.png',
    'gray-wp2.png',
    'gray-wp3.png',
    'gray-wp4.png',
    'gray-wp5.png',
    'gray-wp6.png',
    'gray-wp7.png'
];

let currentIndex = Math.floor(Math.random() * images.length); // Start with a random image

function changeBackground() {
    const container = document.querySelector('.background-container');
    container.style.backgroundImage = `url(${images[currentIndex]})`;
    currentIndex = (currentIndex + 1) % images.length;
}

// Change background every 5 seconds
setInterval(changeBackground, 5000);

// Initial call to set the first image
changeBackground();
